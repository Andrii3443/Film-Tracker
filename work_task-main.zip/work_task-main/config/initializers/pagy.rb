Pagy::DEFAULT[:items] = 10
